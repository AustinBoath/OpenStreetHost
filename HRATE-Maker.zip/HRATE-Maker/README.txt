HRATE MAKER (basic version)
===========================
Double-click HRATE-Maker.exe. That's it.

It will:
  1. Check for Docker Desktop (offers to install it, and starts it if it's closed)
  2. Download the OpenStreetMap "Rails Port" website code from GitHub
  3. Configure it for http://localhost:2014
  4. Build the server image            (slowest step, 5-15 min first time)
  5. Create an EMPTY PostgreSQL map database
  6. Create an admin account   (user: admin   password: hrate-admin-2014)
  7. Start the site and open your browser at http://localhost:2014

Everything lives in  C:\Users\<you>\HRATE
Run the exe again later to Start / Stop / Delete-and-start-over.

Requirements: Windows 10/11 64-bit, internet, ~5 GB free disk,
Docker Desktop (the exe can install it for you via winget).

Windows may show a SmartScreen warning because the exe is unsigned:
click "More info" -> "Run anyway". Source code is in the /source folder.

Not included yet (planned for later versions): map tile server (the
background map layer will be blank/unstyled), presets, custom ports.
