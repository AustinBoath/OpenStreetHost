@echo off
REM Rebuild HRATE-Maker.exe from source (needs Go: https://go.dev/dl/)
go build -ldflags="-s -w" -o ..\HRATE-Maker.exe .
