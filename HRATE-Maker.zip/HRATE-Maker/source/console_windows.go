//go:build windows

package main

import (
	"syscall"
	"unsafe"
)

// enableANSI turns on colour output and sets the window title.
func enableANSI() {
	k := syscall.NewLazyDLL("kernel32.dll")
	h, err := syscall.GetStdHandle(syscall.STD_OUTPUT_HANDLE)
	if err == nil {
		var mode uint32
		k.NewProc("GetConsoleMode").Call(uintptr(h), uintptr(unsafe.Pointer(&mode)))
		k.NewProc("SetConsoleMode").Call(uintptr(h), uintptr(mode|0x0004))
	}
	title, _ := syscall.UTF16PtrFromString("HRATE Maker")
	k.NewProc("SetConsoleTitleW").Call(uintptr(unsafe.Pointer(title)))
}
