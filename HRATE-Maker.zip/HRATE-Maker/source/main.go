// HRATE Maker - one double-click OpenGeoFiction-style server on localhost:2014
//
// HRATE = "High-Resolution Alternative to Earth" (see wiki.rent-a-planet.com/w/index.php/HRATE)
// This program automates the "Railsport + PostgreSQL" part of the OSM stack using Docker.
package main

import (
	"archive/zip"
	"bufio"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

const (
	port       = "2014"
	siteURL    = "http://localhost:" + port
	adminUser  = "admin"
	adminPass  = "hrate-admin-2014"
	adminEmail = "admin@hrate.local"
	totalSteps = 7
)

var (
	source  = flag.String("source", "openstreetmap/openstreetmap-website", "GitHub owner/repo of the Rails Port to deploy")
	branch  = flag.String("branch", "master", "branch to download")
	dirFlag = flag.String("dir", "", "install folder (default: %USERPROFILE%\\HRATE)")
	compose []string
	stdin   = bufio.NewReader(os.Stdin)
)

// ---------- pretty output ----------

const (
	cReset = "\033[0m"
	cBold  = "\033[1m"
	cDim   = "\033[2m"
	cRed   = "\033[31m"
	cGreen = "\033[32m"
	cYel   = "\033[33m"
	cCyan  = "\033[36m"
)

func banner() {
	fmt.Println(cCyan + cBold)
	fmt.Println(`  _   _ ____    _  _____ _____ `)
	fmt.Println(` | | | |  _ \  / \|_   _| ____|`)
	fmt.Println(` | |_| | |_) |/ _ \ | | |  _|  `)
	fmt.Println(` |  _  |  _ </ ___ \| | | |___ `)
	fmt.Println(` |_| |_|_| \_\_/   \_\_| |_____|`)
	fmt.Println(cReset + cDim + "  High-Resolution Alternative to Earth - maker" + cReset)
	fmt.Println()
}

func step(n int, msg string) {
	fmt.Printf("\n%s%s[%d/%d] %s%s\n", cCyan, cBold, n, totalSteps, msg, cReset)
}
func ok(msg string)   { fmt.Println(cGreen + "  OK  " + cReset + msg) }
func info(msg string) { fmt.Println(cDim + "      " + msg + cReset) }
func warn(msg string) { fmt.Println(cYel + "  !!  " + cReset + msg) }

func pause() {
	fmt.Print("\n" + cDim + "Press Enter to close this window..." + cReset)
	stdin.ReadString('\n')
}

func fatal(msg, hint string) {
	fmt.Println()
	fmt.Println(cRed + cBold + "  ERROR: " + cReset + msg)
	if hint != "" {
		fmt.Println(cYel + "  " + hint + cReset)
	}
	pause()
	os.Exit(1)
}

func ask(prompt string) string {
	fmt.Print(prompt)
	s, _ := stdin.ReadString('\n')
	return strings.TrimSpace(s)
}

// ---------- helpers ----------

func run(dir string, name string, args ...string) error {
	cmd := exec.Command(name, args...)
	cmd.Dir = dir
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	cmd.Env = append(os.Environ(), "COMPOSE_PROJECT_NAME=hrate", "COMPOSE_DOCKER_CLI_BUILD=1")
	return cmd.Run()
}

func dc(dir string, args ...string) error {
	full := append(append([]string{}, compose[1:]...), args...)
	return run(dir, compose[0], full...)
}

func openBrowser(url string) {
	switch runtime.GOOS {
	case "windows":
		exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	case "darwin":
		exec.Command("open", url).Start()
	default:
		exec.Command("xdg-open", url).Start()
	}
}

func exists(p string) bool { _, err := os.Stat(p); return err == nil }

// ---------- step 1: docker ----------

func ensureDocker() {
	if runtime.GOOS == "windows" {
		os.Setenv("PATH", os.Getenv("PATH")+`;C:\Program Files\Docker\Docker\resources\bin`)
	}
	if _, err := exec.LookPath("docker"); err != nil {
		warn("Docker is not installed. HRATE needs it to run the database and website.")
		if _, werr := exec.LookPath("winget"); werr == nil {
			if strings.EqualFold(ask("      Install Docker Desktop automatically now? [Y/n] "), "n") {
				openBrowser("https://www.docker.com/products/docker-desktop/")
				fatal("Install Docker Desktop, start it, then double-click HRATE Maker again.", "")
			}
			err := run("", "winget", "install", "-e", "--id", "Docker.DockerDesktop",
				"--accept-package-agreements", "--accept-source-agreements")
			if err != nil {
				openBrowser("https://www.docker.com/products/docker-desktop/")
				fatal("Automatic install failed. I opened the Docker download page for you.",
					"Install it, start Docker Desktop, then run HRATE Maker again.")
			}
			fatal("Docker Desktop was installed.",
				"Restart your PC if Docker asks you to, open Docker Desktop once, then double-click HRATE Maker again.")
		}
		openBrowser("https://www.docker.com/products/docker-desktop/")
		fatal("I opened the Docker Desktop download page.", "Install it, start it, then run HRATE Maker again.")
	}

	if exec.Command("docker", "info").Run() != nil {
		warn("Docker is installed but not running. Starting Docker Desktop...")
		if runtime.GOOS == "windows" {
			exec.Command(`C:\Program Files\Docker\Docker\Docker Desktop.exe`).Start()
		}
		deadline := time.Now().Add(4 * time.Minute)
		for time.Now().Before(deadline) {
			if exec.Command("docker", "info").Run() == nil {
				break
			}
			fmt.Print(cDim + "." + cReset)
			time.Sleep(4 * time.Second)
		}
		fmt.Println()
		if exec.Command("docker", "info").Run() != nil {
			fatal("Docker did not start in time.", "Open Docker Desktop manually, wait for it to say 'running', then try again.")
		}
	}

	if exec.Command("docker", "compose", "version").Run() == nil {
		compose = []string{"docker", "compose"}
	} else if _, err := exec.LookPath("docker-compose"); err == nil {
		compose = []string{"docker-compose"}
	} else {
		fatal("Docker Compose was not found.", "Update Docker Desktop to the latest version.")
	}
	ok("Docker is ready")
}

// ---------- step 2: download ----------

func download(url, dest string) error {
	resp, err := http.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return fmt.Errorf("download failed: HTTP %d (%s)", resp.StatusCode, url)
	}
	f, err := os.Create(dest)
	if err != nil {
		return err
	}
	defer f.Close()
	buf := make([]byte, 64*1024)
	var total int64
	last := time.Now()
	for {
		n, rerr := resp.Body.Read(buf)
		if n > 0 {
			f.Write(buf[:n])
			total += int64(n)
			if time.Since(last) > 200*time.Millisecond {
				fmt.Printf("\r      %.1f MB downloaded", float64(total)/1048576)
				last = time.Now()
			}
		}
		if rerr == io.EOF {
			break
		}
		if rerr != nil {
			return rerr
		}
	}
	fmt.Printf("\r      %.1f MB downloaded\n", float64(total)/1048576)
	return nil
}

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	os.MkdirAll(filepath.Dir(dst), 0o755)
	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer out.Close()
	_, err = io.Copy(out, in)
	return err
}

func copyPath(src, dst string) error {
	st, err := os.Stat(src)
	if err != nil {
		return err
	}
	if !st.IsDir() {
		return copyFile(src, dst)
	}
	return filepath.Walk(src, func(p string, fi os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		rel, _ := filepath.Rel(src, p)
		t := filepath.Join(dst, rel)
		if fi.IsDir() {
			return os.MkdirAll(t, 0o755)
		}
		return copyFile(p, t)
	})
}

// unzip extracts a GitHub zipball, stripping the top folder.
// The OSM repo contains git symlinks which Windows can't always create, so
// they are replaced with real copies of what they point to.
func unzip(zipPath, dest string) error {
	r, err := zip.OpenReader(zipPath)
	if err != nil {
		return err
	}
	defer r.Close()
	type link struct{ path, target string }
	var links []link
	cleanDest := filepath.Clean(dest) + string(os.PathSeparator)
	count := 0
	for _, f := range r.File {
		i := strings.Index(f.Name, "/")
		if i < 0 {
			continue
		}
		rel := f.Name[i+1:]
		if rel == "" {
			continue
		}
		target := filepath.Join(dest, filepath.FromSlash(rel))
		if !strings.HasPrefix(target, cleanDest) {
			continue // zip-slip guard
		}
		if f.FileInfo().IsDir() {
			os.MkdirAll(target, 0o755)
			continue
		}
		os.MkdirAll(filepath.Dir(target), 0o755)
		rc, err := f.Open()
		if err != nil {
			return err
		}
		if f.Mode()&os.ModeSymlink != 0 {
			b, _ := io.ReadAll(rc)
			rc.Close()
			links = append(links, link{target, strings.TrimSpace(string(b))})
			continue
		}
		out, err := os.Create(target)
		if err != nil {
			rc.Close()
			return err
		}
		io.Copy(out, rc)
		out.Close()
		rc.Close()
		count++
		if count%500 == 0 {
			fmt.Printf("\r      %d files extracted", count)
		}
	}
	for pass := 0; pass < 3 && len(links) > 0; pass++ {
		var left []link
		for _, l := range links {
			src := filepath.Join(filepath.Dir(l.path), filepath.FromSlash(l.target))
			if copyPath(src, l.path) != nil {
				left = append(left, l)
			}
		}
		links = left
	}
	fmt.Printf("\r      %d files extracted\n", count)
	if len(links) > 0 {
		warn(fmt.Sprintf("%d symlinks could not be resolved (usually harmless)", len(links)))
	}
	return nil
}

// ---------- step 3: configure ----------

func configure(app string) error {
	cfg := filepath.Join(app, "config")
	if err := copyFile(filepath.Join(cfg, "example.storage.yml"), filepath.Join(cfg, "storage.yml")); err != nil {
		return fmt.Errorf("storage.yml: %w", err)
	}
	if err := copyFile(filepath.Join(cfg, "docker.database.yml"), filepath.Join(cfg, "database.yml")); err != nil {
		return fmt.Errorf("database.yml (is this a Docker-ready Rails Port?): %w", err)
	}
	settings := "server_url: \"localhost:" + port + "\"\nserver_protocol: \"http\"\n"
	if err := os.WriteFile(filepath.Join(cfg, "settings.local.yml"), []byte(settings), 0o644); err != nil {
		return err
	}

	// move the published port from 3000 to 2014
	patched := false
	for _, n := range []string{"docker-compose.yml", "compose.yml", "compose.yaml", "docker-compose.yaml"} {
		p := filepath.Join(app, n)
		b, err := os.ReadFile(p)
		if err != nil {
			continue
		}
		s := string(b)
		if strings.Contains(s, "3000:3000") {
			s = strings.ReplaceAll(s, "3000:3000", port+":3000")
			s = strings.ReplaceAll(s, "localhost:3000", "localhost:"+port)
			if err := os.WriteFile(p, []byte(s), 0o644); err != nil {
				return err
			}
			patched = true
		}
		break
	}
	if !patched {
		return fmt.Errorf("could not find the web port mapping in the compose file")
	}

	seed := `begin
  pw = "` + adminPass + `"
  u = User.find_by(display_name: "` + adminUser + `") || User.new
  u.display_name = "` + adminUser + `"
  u.email = "` + adminEmail + `"
  u.pass_crypt = pw
  u.pass_crypt_confirmation = pw
  u.status = "active"
  u.email_valid = true
  u.terms_seen = true
  u.terms_agreed = Time.now.utc if u.respond_to?(:terms_agreed=)
  u.tou_agreed = Time.now.utc if u.respond_to?(:tou_agreed=)
  u.data_public = true if u.respond_to?(:data_public=)
  u.save!
  %w[administrator moderator].each do |role|
    UserRole.find_or_create_by!(user_id: u.id, role: role, granter_id: u.id)
  end
  puts "HRATE_SEED_OK"
rescue => e
  puts "HRATE_SEED_FAILED: #{e.class}: #{e.message}"
end
`
	return os.WriteFile(filepath.Join(app, "hrate_seed.rb"), []byte(seed), 0o644)
}

// ---------- step 7: wait for site ----------

func waitForSite(timeout time.Duration) bool {
	deadline := time.Now().Add(timeout)
	client := &http.Client{Timeout: 5 * time.Second}
	for time.Now().Before(deadline) {
		resp, err := client.Get(siteURL + "/api/0.6/capabilities")
		if err == nil {
			resp.Body.Close()
			if resp.StatusCode == 200 {
				return true
			}
		}
		fmt.Print(cDim + "." + cReset)
		time.Sleep(3 * time.Second)
	}
	return false
}

func startAndOpen(app string) {
	if err := dc(app, "up", "-d"); err != nil {
		fatal("Could not start the containers: "+err.Error(), "Check Docker Desktop is running, then try again.")
	}
	fmt.Print("      Waiting for the website to wake up (first start can take a few minutes) ")
	if !waitForSite(12 * time.Minute) {
		fmt.Println()
		fatal("The website did not respond on "+siteURL,
			"Check logs with:  docker compose -p hrate logs web   (in "+app+")")
	}
	fmt.Println()
	ok("Your HRATE is live at " + siteURL)
	openBrowser(siteURL)
}

func summary() {
	fmt.Println()
	fmt.Println(cGreen + cBold + "  =============================================" + cReset)
	fmt.Println(cGreen + cBold + "   YOUR HRATE IS RUNNING:  " + siteURL + cReset)
	fmt.Println(cGreen + cBold + "  =============================================" + cReset)
	fmt.Println("   Admin login   user:     " + adminUser)
	fmt.Println("                 password: " + adminPass)
	fmt.Println(cDim + "   The map starts empty. Click 'Edit' to draw with iD, or connect JOSM to " + siteURL + "/api")
	fmt.Println("   Close Docker Desktop (or run this again and choose Stop) to shut it down." + cReset)
}

// ---------- menu for an existing install ----------

func existingMenu(root, app string) {
	fmt.Println("An HRATE already exists at " + cBold + root + cReset)
	fmt.Println("   [1] Start it and open the site  (default)")
	fmt.Println("   [2] Stop it")
	fmt.Println("   [3] Delete everything and start over")
	switch ask("\n   Choose 1-3 [1]: ") {
	case "2":
		dc(app, "stop")
		ok("Stopped.")
	case "3":
		if ask("   Type DELETE to erase this HRATE and all its map data: ") != "DELETE" {
			warn("Cancelled.")
			return
		}
		dc(app, "down", "-v", "--remove-orphans")
		os.RemoveAll(root)
		ok("Erased. Run HRATE Maker again for a fresh planet.")
	default:
		step(1, "Starting your HRATE")
		startAndOpen(app)
		summary()
	}
}

// ---------- main ----------

func main() {
	flag.Parse()
	enableANSI()
	banner()

	root := *dirFlag
	if root == "" {
		home, _ := os.UserHomeDir()
		root = filepath.Join(home, "HRATE")
	}
	app := filepath.Join(root, "site")
	marker := filepath.Join(root, ".hrate-installed")

	step(1, "Checking Docker")
	ensureDocker()

	if exists(marker) {
		fmt.Println()
		existingMenu(root, app)
		pause()
		return
	}

	step(2, "Downloading the OSM Rails Port ("+*source+")")
	os.RemoveAll(app)
	if err := os.MkdirAll(root, 0o755); err != nil {
		fatal(err.Error(), "")
	}
	zipPath := filepath.Join(root, "source.zip")
	url := "https://codeload.github.com/" + *source + "/zip/refs/heads/" + *branch
	if err := download(url, zipPath); err != nil {
		fatal(err.Error(), "Check your internet connection and try again.")
	}
	if err := unzip(zipPath, app); err != nil {
		fatal("Could not unpack the download: "+err.Error(), "")
	}
	os.Remove(zipPath)
	ok("Source ready in " + app)

	step(3, "Configuring for localhost:"+port)
	if err := configure(app); err != nil {
		fatal(err.Error(), "The chosen source may not include Docker support. Try the default source.")
	}
	ok("Configuration written")

	step(4, "Building the server image (the slow part - 5 to 15 minutes the first time)")
	if err := dc(app, "build"); err != nil {
		fatal("Docker build failed: "+err.Error(), "Scroll up for the reason. Make sure Docker Desktop is running Linux containers.")
	}
	ok("Image built")

	step(5, "Creating the empty PostgreSQL map database")
	if err := dc(app, "up", "-d", "db"); err != nil {
		fatal("Could not start the database: "+err.Error(), "")
	}
	migrated := false
	for i := 1; i <= 8 && !migrated; i++ {
		info(fmt.Sprintf("Running migrations (attempt %d/8)...", i))
		if dc(app, "run", "--rm", "-T", "web", "bundle", "exec", "rails", "db:migrate") == nil {
			migrated = true
		} else {
			time.Sleep(8 * time.Second)
		}
	}
	if !migrated {
		fatal("Database setup failed.", "Scroll up for the error message.")
	}
	ok("Empty planet database created")

	step(6, "Creating your admin account")
	if err := dc(app, "run", "--rm", "-T", "web", "bundle", "exec", "rails", "runner", "hrate_seed.rb"); err != nil {
		warn("Could not auto-create the admin user. You can still register on the site.")
	} else {
		ok("Admin account created")
	}

	step(7, "Launching the website on port "+port)
	startAndOpen(app)
	os.WriteFile(marker, []byte(time.Now().Format(time.RFC3339)), 0o644)
	summary()
	pause()
}
