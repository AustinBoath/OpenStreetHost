module hrate

go 1.22
